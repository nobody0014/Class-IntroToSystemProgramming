/* Name:
 * ID:
 */
#include <stdio.h>
#include <stdlib.h>
#include "mergesort.h"

void merge(Entry *output, Entry *L, int nL, Entry *R, int nR) {
    // IMPLEMENT
}

void merge_sort(Entry *entries, int n) {
    // IMPLEMENT
}

/*
TEST: ./mergesort < test.in
OUTPUT:
1 lsdfjl
2 ghijk
3 ksdljf
5 abc
6 def
*/
int main(void) {
    // IMPLEMENT
}
